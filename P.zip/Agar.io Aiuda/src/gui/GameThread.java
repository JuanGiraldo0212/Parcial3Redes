package gui;

import java.io.IOException;

import connection.Server;
import model.Game;

public class GameThread extends Thread{
	
	private int countDown;
	private int limit;
	private Server server;
	
	public GameThread(Server server,int limit) {
		this.server=server;
		this.limit=limit;
		this.countDown=limit;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
		try {
			Game game=server.getGame();
			while(game.isActive()) {
				
				if(game.onePlayer()) {
					game.setActive(false);
					try {
						server.upDateLogs();
					} catch (NumberFormatException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}	
				
				if(countDown>0) {
					Thread.sleep(1000);
					countDown--;
				}
				else {
					game.setActive(false);
					try {
						server.upDateLogs();
					} catch (NumberFormatException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}
			}
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
